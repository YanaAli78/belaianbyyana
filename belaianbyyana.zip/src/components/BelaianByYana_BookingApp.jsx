/*
Belaian by Yana - Booking Demo Component (React + Tailwind)
- Bahasa Melayu penuh UI
- Tema: lembut pastel pink
- Simpan tempahan ke localStorage (key: 'belaian_bookings')
- Notifikasi: membuka WhatsApp dengan mesej pra-isian ke nombor pemilik (01110292324 => +60 11 1029 2324)

Auto-reply message to customer (shown in WhatsApp text for customer):
"Terima kasih sayang 💕 Tempahan anda diterima. Kami akan sahkan slot sekejap lagi."
*/

import React, { useEffect, useState } from "react";
import bg from "../assets/spa_woman.svg";

export default function BelaianByYanaBookingApp() {
  const OWNER_WA = "601110292324"; // +60 11 1029 2324 (for wa.me)
  const SERVICES = [
    { id: "1hr", name: "Aromatherapy Fullbody - 1 jam", durationMin: 60, price: 120 },
    { id: "2hr", name: "Aromatherapy Fullbody - 2 jam", durationMin: 120, price: 190 },
  ];
  const OPEN_HOUR = 10; // 10 pagi
  const CLOSE_HOUR = 22; // 10 malam

  const [selectedService, setSelectedService] = useState(SERVICES[0].id);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [bookings, setBookings] = useState([]);
  const [adminMode, setAdminMode] = useState(false);
  const [blockedDates, setBlockedDates] = useState({});

  useEffect(() => {
    const raw = localStorage.getItem("belaian_bookings");
    if (raw) setBookings(JSON.parse(raw));
    const rawBlocked = localStorage.getItem("belaian_blocked");
    if (rawBlocked) setBlockedDates(JSON.parse(rawBlocked));
  }, []);

  useEffect(() => {
    localStorage.setItem("belaian_bookings", JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem("belaian_blocked", JSON.stringify(blockedDates));
  }, [blockedDates]);

  function startTimesForService(serviceId) {
    const svc = SERVICES.find((s) => s.id === serviceId);
    const slots = [];
    const lastStart = CLOSE_HOUR - Math.ceil(svc.durationMin / 60);
    for (let h = OPEN_HOUR; h <= lastStart; h++) {
      const hh = String(h).padStart(2, "0");
      slots.push(`${hh}:00`);
    }
    return slots;
  }

  function isSlotAvailable(dateStr, startTime, serviceId) {
    if (!dateStr || !startTime) return true;
    if (blockedDates[dateStr] && blockedDates[dateStr].includes(startTime)) return false;

    const svc = SERVICES.find((s) => s.id === serviceId);
    const start = new Date(`${dateStr}T${startTime}:00`);
    const end = new Date(start.getTime() + svc.durationMin * 60000);

    for (const b of bookings) {
      if (b.date !== dateStr) continue;
      const bStart = new Date(`${b.date}T${b.time}:00`);
      const bSvc = SERVICES.find((s) => s.id === b.serviceId);
      const bEnd = new Date(bStart.getTime() + bSvc.durationMin * 60000);

      if (start < bEnd && end > bStart) return false;
    }
    return true;
  }

  function availableSlotsForDate(dateStr, serviceId) {
    const slots = startTimesForService(serviceId);
    return slots.map((t) => ({ time: t, available: isSlotAvailable(dateStr, t, serviceId) }));
  }

  function handleConfirmBooking(e) {
    e.preventDefault();
    if (!date || !time || !name || !phone || !address) {
      alert("Sila isi semua medan yang diperlukan.");
      return;
    }
    if (!isSlotAvailable(date, time, selectedService)) {
      alert("Maaf, slot tersebut telah penuh. Sila pilih slot lain.");
      return;
    }

    const id = `bk_${Date.now()}`;
    const newBooking = { id, serviceId: selectedService, date, time, name, phone, address, notes };
    setBookings((s) => [newBooking, ...s]);

    // message to owner
    const svc = SERVICES.find((s) => s.id === selectedService);
    const ownerMsg = encodeURIComponent(`✅ Tempahan Baru - Belaian by Yana\nNama: ${name}\nWhatsapp: ${phone}\nServis: ${svc.name} (RM${svc.price})\nTarikh: ${date}\nMasa: ${time}\nAlamat: ${address}\nNota: ${notes}`);
    const waOwnerLink = `https://wa.me/${OWNER_WA}?text=${ownerMsg}`;
    window.open(waOwnerLink, "_blank");

    // customer auto-reply (customer WA message prefill)
    const customerMsg = encodeURIComponent("Terima kasih sayang 💕 Tempahan anda diterima. Kami akan sahkan slot sekejap lagi.");
    const waCustomerLink = `https://wa.me/${phone.replace(/^0/, "6")}?text=${customerMsg}`;

    // clear
    setName("");
    setPhone("");
    setAddress("");
    setNotes("");
    alert("Tempahan anda telah dihantar. Kami akan mengesahkan melalui WhatsApp.");
  }

  function toggleAdmin() {
    const pw = prompt("Masukkan kod admin untuk akses papan admin (contoh: yana123)");
    if (pw === "yana123") setAdminMode(!adminMode);
    else if (pw !== null) alert("Kod salah.");
  }

  function markBlocked(dateStr, timeSlot) {
    setBlockedDates((prev) => {
      const cur = { ...prev };
      cur[dateStr] = cur[dateStr] || [];
      if (cur[dateStr].includes(timeSlot)) {
        cur[dateStr] = cur[dateStr].filter((t) => t !== timeSlot);
        if (cur[dateStr].length === 0) delete cur[dateStr];
      } else {
        cur[dateStr].push(timeSlot);
      }
      return cur;
    });
  }

  function removeBooking(id) {
    if (!confirm("Padam tempahan ini?")) return;
    setBookings((s) => s.filter((b) => b.id !== id));
  }

  function todayISO() {
    const d = new Date();
    return d.toISOString().slice(0, 10);
  }

  const slots = date ? availableSlotsForDate(date, selectedService) : [];

  return (
    <div className="min-h-screen p-6 bg-gradient-to-b from-pink-50 to-white" style={{backgroundImage:`url(${bg})`, backgroundRepeat:'no-repeat', backgroundPosition:'right bottom'}}>
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow p-6">
        <header className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-pink-100 flex items-center justify-center text-pink-700 font-bold">BY</div>
          <div>
            <h1 className="text-2xl font-semibold">Belaian by Yana</h1>
            <p className="text-sm text-gray-600">Aromatherapy Mobile Spa — Kami datang ke rumah anda 💆‍♀️</p>
          </div>
          <div className="ml-auto">
            <button onClick={toggleAdmin} className="px-3 py-1 text-sm border rounded-md">Papan Admin</button>
          </div>
        </header>

        <section className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-lg font-medium">Pilih Servis</h2>
            <div className="mt-3 space-y-2">
              {SERVICES.map((s) => (
                <label key={s.id} className={`block p-3 rounded-lg border ${selectedService === s.id ? "border-pink-300 bg-pink-50" : "border-gray-200"}`}>
                  <input
                    type="radio"
                    name="service"
                    value={s.id}
                    checked={selectedService === s.id}
                    onChange={() => setSelectedService(s.id)}
                    className="mr-2"
                  />
                  <span className="font-medium">{s.name}</span>
                  <div className="text-sm text-gray-600">Tempoh: {s.durationMin / 60} jam • Harga: RM{s.price}</div>
                </label>
              ))}
            </div>

            <form onSubmit={handleConfirmBooking} className="mt-6">
              <h3 className="font-medium">Pilih Tarikh & Masa</h3>
              <div className="mt-2 flex gap-2 items-center">
                <input type="date" min={todayISO()} value={date} onChange={(e) => { setDate(e.target.value); setTime(""); }} className="border rounded p-2" />
                <select value={time} onChange={(e) => setTime(e.target.value)} className="border rounded p-2">
                  <option value="">Pilih masa</option>
                  {slots.map((s) => (
                    <option key={s.time} value={s.time} disabled={!s.available}>{s.time} {s.available ? "(Tersedia)" : "(Penuh)"}</option>
                  ))}
                </select>
              </div>

              <h3 className="mt-4 font-medium">Maklumat Pelanggan</h3>
              <div className="grid grid-cols-1 gap-3 mt-2">
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nama penuh" className="border p-2 rounded" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Nombor WhatsApp" className="border p-2 rounded" />
                <input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Alamat untuk urutan" className="border p-2 rounded" />
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Nota tambahan (optional)" className="border p-2 rounded" />
              </div>

              <div className="mt-4 flex gap-3">
                <button type="submit" className="px-4 py-2 bg-pink-400 text-white rounded">Sahkan Tempahan</button>
                <button type="button" onClick={() => { setDate(""); setTime(""); setName(""); setPhone(""); setAddress(""); setNotes(""); }} className="px-4 py-2 border rounded">Reset</button>
              </div>
            </form>

            <div className="mt-6 text-sm text-gray-600">
              Nota: Slot yang penuh akan ditandakan sebagai "Penuh". Selepas sahkan, WhatsApp akan dibuka untuk menghantar notifikasi kepada pemilik Belaian by Yana.
            </div>
          </div>

          <aside>
            <div className="p-4 rounded-lg border bg-pink-50">
              <h3 className="font-medium">Garis Masa Operasi</h3>
              <p className="text-sm mt-2">10:00 pagi — 10:00 malam setiap hari</p>

              <h3 className="font-medium mt-4">Slot untuk tarikh terpilih</h3>
              {!date && <p className="text-sm mt-2 text-gray-500">Sila pilih tarikh untuk lihat slot tersedia.</p>}
              {date && (
                <div className="mt-2 space-y-2">
                  {slots.map((s) => (
                    <div key={s.time} className={`flex items-center justify-between p-2 rounded ${s.available ? "border border-green-100 bg-white" : "opacity-60 border border-gray-100 bg-gray-50"}`}>
                      <div>{s.time}</div>
                      <div className="text-sm">
                        {s.available ? <span className="text-green-600">Tersedia</span> : <span className="text-red-500">Penuh</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <h3 className="font-medium mt-4">Hubungi & Notifikasi</h3>
              <p className="text-sm mt-2">Notifikasi dihantar ke WhatsApp pemilik apabila tempahan dibuat.</p>
              <p className="text-sm mt-2 font-semibold">Nombor pemilik: 011-1029 2324</p>
            </div>

            <div className="mt-4 p-4 border rounded">
              <h3 className="font-medium">Contoh Mesej WhatsApp</h3>
              <pre className="text-xs mt-2 bg-white p-2 rounded">Nama: Aina\nServis: Aromatherapy 1 jam\nTarikh: 2025-10-20\nMasa: 15:00\nAlamat: Ukay Bistari\nNota: Bawa minyak lavender</pre>
            </div>
          </aside>
        </section>

        {adminMode && (
          <section className="mt-6">
            <h2 className="text-lg font-medium">Papan Admin</h2>
            <div className="mt-3 grid md:grid-cols-2 gap-4">
              <div className="p-4 border rounded">
                <h4 className="font-medium">Tempahan Terkini</h4>
                {bookings.length === 0 && <p className="text-sm text-gray-500">Tiada tempahan lagi.</p>}
                <ul className="mt-2 space-y-2">
                  {bookings.map((b) => {
                    const svc = SERVICES.find((s) => s.id === b.serviceId);
                    return (
                      <li key={b.id} className="p-2 border rounded flex justify-between items-start">
                        <div>
                          <div className="font-medium">{b.name} — {svc.name}</div>
                          <div className="text-sm text-gray-600">{b.date} • {b.time}</div>
                          <div className="text-sm">{b.address}</div>
                        </div>
                        <div className="flex flex-col gap-2">
                          <button onClick={() => { window.open(`https://wa.me/${OWNER_WA}?text=${encodeURIComponent(`Hai ${b.name}, tempahan anda sedang diproses oleh Belaian by Yana.`)}`, "_blank"); }} className="text-sm px-3 py-1 border rounded">Hubungi</button>
                          <button onClick={() => removeBooking(b.id)} className="text-sm px-3 py-1 bg-red-100 rounded">Padam</button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>

              <div className="p-4 border rounded">
                <h4 className="font-medium">Urus Slot & Tarikh</h4>
                <p className="text-sm mt-2">Blok atau buka semula slot tertentu (contoh: cuti atau outstation).</p>
                <div className="mt-3">
                  <input type="date" min={todayISO()} className="border p-2 rounded" id="blockDate" />
                  <select id="blockTime" className="border p-2 rounded ml-2">
                    <option value="">Pilih masa</option>
                    {startTimesForService(SERVICES[0].id).map((t) => (<option key={t} value={t}>{t}</option>))}
                  </select>
                  <div className="mt-2">
                    <button onClick={() => {
                      const d = document.getElementById("blockDate").value;
                      const t = document.getElementById("blockTime").value;
                      if (!d || !t) return alert("Sila pilih tarikh & masa untuk di-block.");
                      markBlocked(d, t);
                    }} className="px-3 py-1 bg-pink-300 text-white rounded">Tanda/Un-tanda Block</button>
                  </div>
                </div>

                <div className="mt-4">
                  <h5 className="font-medium">Tarikh & Slot Terblock</h5>
                  <ul className="mt-2 text-sm space-y-2">
                    {Object.keys(blockedDates).length === 0 && <li className="text-gray-500">Tiada slot diblock.</li>}
                    {Object.entries(blockedDates).map(([d, arr]) => (
                      <li key={d} className="flex justify-between items-center border p-2 rounded">
                        <div>
                          <div className="font-medium">{d}</div>
                          <div className="text-sm">{arr.join(", ")}</div>
                        </div>
                        <div>
                          <button onClick={() => { if (confirm(`Buang semua block untuk ${d}?`)) { setBlockedDates((prev) => { const cur = { ...prev }; delete cur[d]; return cur; }); } }} className="px-2 py-1 border rounded">Buang</button>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </section>
        )}

        <footer className="mt-6 text-center text-sm text-gray-500">© Belaian by Yana • Dihasilkan untuk demo tempahan mobile spa</footer>
      </div>
    </div>
  );
}
