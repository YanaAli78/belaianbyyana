import React from 'react'
import BelaianByYanaBookingApp from './components/BelaianByYana_BookingApp'

export default function App(){
  return <BelaianByYanaBookingApp />
}
