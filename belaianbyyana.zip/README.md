# Belaian by Yana - Booking (Demo)

Satu projek React + Tailwind ringkas untuk sistem tempahan **Belaian by Yana**.

## Ciri-ciri
- Bahasa Melayu penuh UI
- Pilih servis 1 jam / 2 jam
- Pilih tarikh & masa; slot yang bertindih akan ditandakan Penuh
- Simpan tempahan di `localStorage`
- Notifikasi ke WhatsApp pemilik melalui `wa.me` (nombor: +60 11-1029 2324)
- Auto-reply teks pelanggan tersedia (dipra-isikan, tidak dihantar automatik kerana WhatsApp API diperlukan)

## Cara jalankan (lokal)
1. Pasang Node.js (v18+ disyorkan)
2. `npm install`
3. `npm run dev`
4. Buka `http://localhost:5173`

## Nota untuk deploy ke Vercel
- Daftar GitHub & Vercel.
- Upload repo ke GitHub, import ke Vercel, dan deploy.
- Nama domain Vercel akan menjadi `belaianbyyana.vercel.app` setelah deploy.
